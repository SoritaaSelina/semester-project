#include <iostream>
#include <string>
#include <vector>

using namespace std;



	class Room{ 
	public:
	int roomNumber;
	bool isoccupied;      
	string guestName;
	
	Room(int roomNumber){
	this->roomNumber=roomNumber;	
	isoccupied=false;
	guestName="";	
	}
	
	void checkIn(string guestName){
	isoccupied=true;	
	this->guestName=guestName;	
	}
	void checkOut(){
	isoccupied=false;
	guestName="";	
	}
};
	
	class Hotel{
    public:	 
	string name;     
	vector<Room> rooms;
	Hotel(string name,int numberOfRooms){
	this->name = name;	
	 for(int i = 1; i<= numberOfRooms; i++){
	 rooms.push_back(Room(i));
	 }
	 	   	
	}
	
	void displayRooms(){
	cout<<"Room in"<<name<<":"<<endl;	
	 for(int i=0; i<rooms.size(); i++){
	 cout<<"Room"<<rooms[i].roomNumber<<":";
	  if(rooms[i].isoccupied){
	  	cout<<"occupied by"<<rooms[i].guestName<<endl;
	  } else{
	  	cout<<"Avaliable"<<endl;
	  	
	  }
	 	
	 }	
	}
	
	void checkIn(int roomNumber,string guestName){
		for(int i=0; i<rooms.size(); i++){
			if(rooms[i].roomNumber==roomNumber){
			rooms[i].checkIn(guestName);
			cout<<"checked in"<<guestName<<"to room"<<roomNumber<<endl;
				
	return;
}
}
 cout<<"Room"<<roomNumber<<"notfound"<<endl;
}
   void checkOut(int roomNumber){
    for(int i=0; i<rooms.size();i++){
	if(rooms[i].roomNumber==roomNumber){
	 rooms[i].checkOut();
	cout<<"check out room"<<roomNumber<<endl;
	
	return;
}
}
  cout<<"Room"<<roomNumber<<"not found"<<endl;	

}
};
  int main(){
  Hotel hotel("My Hostel",10);
  hotel.displayRooms();
  hotel.checkIn(5,"hassan ibramhim");
  hotel.checkIn(7,"jane smith");
  hotel.displayRooms();
  hotel.checkOut(5);
  hotel.displayRooms();
  
   return 0;
}
